"""Global constants for finding the path"""
from pathlib import Path
JSON_FILES_PATH = str(Path.home()) + "/PycharmProjects/2022_EG4_BASECODE_2/src/JsonFiles/"
JSON_FILES_RF2_PATH = JSON_FILES_PATH + "/RF2/"
